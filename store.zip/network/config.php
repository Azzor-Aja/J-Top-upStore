<?php 
$server = "localhost";
$user = "root";
$pass = "";
$database = "db_store";

$connect = mysqli_connect ($server, $user, $pass, $database);
?>