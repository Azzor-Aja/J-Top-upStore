function openNav() {
    document.getElementById("toggle-icons").classList.toggle('slide')
    console.log("toggle-icons");  
  }