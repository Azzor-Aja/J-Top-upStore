
function openNav() {
    document.getElementById("toggle-icons").classList.toggle('slide')    
  }
  